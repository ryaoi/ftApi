# FtApi

## Usage
You need to have uid and secret from 42 application panel
tons of love for the dev Team who makde RESTful API.
You guys rock !!!

## Example

![example](https://github.com/ryaoi/ftApi/blob/master/img/example.png)
