from setuptools import setup, find_packages

setup(
    name='FtApi',
    version='1.1', 
    author="Ryota YAOI",
    packages=find_packages())
